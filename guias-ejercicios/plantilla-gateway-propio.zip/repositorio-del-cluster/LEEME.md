# Plantilla del repositorio del clúster (gateway propio)

1. Elijan una opción y copien su carpeta `gateway` a la raíz del repositorio:
   - Opción A (Node): `opcion-a-node/gateway`
   - Opción B (Python): `opcion-b-python/gateway`
2. Borren la carpeta de la opción que no usen.
3. Copien `.env.example` como `.env` y completen los valores.
4. Sigan la guía "Construir un API Gateway propio".

Si usan la Opción B, ajusten el trabajo `validar` de `.github/workflows/gateway.yml` como indica la guía.
