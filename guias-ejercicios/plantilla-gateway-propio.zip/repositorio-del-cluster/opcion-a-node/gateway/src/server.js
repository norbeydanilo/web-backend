const fs = require("fs");
const path = require("path");
const crypto = require("crypto");
const express = require("express");
const YAML = require("yaml");
const { SignJWT, jwtVerify } = require("jose");

// ---------- Configuración (todo por variables de entorno) ----------
const PORT = process.env.PORT || 8080;
const JWT_SECRET = process.env.JWT_SECRET;
const GATEWAY_SECRET = process.env.GATEWAY_SECRET;
const ISSUER = process.env.JWT_ISSUER || "emisor-cluster";
const AUDIENCE = process.env.JWT_AUDIENCE || "cluster";
const EXPIRA_SEG = Number(process.env.TOKEN_EXPIRA_SEG || 300);
const TIMEOUT_MS = Number(process.env.TIMEOUT_MS || 3000);
const DIR_CONTRATOS = process.env.DIR_CONTRATOS || path.join(process.cwd(), "contratos");
const CLIENTES = JSON.parse(process.env.CLIENTES_JSON || "{}");

if (!JWT_SECRET || JWT_SECRET.length < 32 || !GATEWAY_SECRET) {
  console.error("Se requieren JWT_SECRET (mínimo 32 caracteres) y GATEWAY_SECRET");
  process.exit(1);
}
const clave = new TextEncoder().encode(JWT_SECRET);

// ---------- Tabla de rutas, construida desde los contratos OpenAPI ----------
const METODOS = ["get", "post", "put", "patch", "delete"];
const servicios = {}; // prefijo -> { url, rutas: [...] }
const faltantes = [];

for (const archivo of fs.readdirSync(DIR_CONTRATOS).filter((f) => f.endsWith(".yaml"))) {
  const nombre = path.basename(archivo, ".yaml");
  const variable = nombre.toUpperCase().replace(/-/g, "_") + "_URL";
  const url = process.env[variable];
  if (!url) { faltantes.push(variable); continue; }
  const contrato = YAML.parse(fs.readFileSync(path.join(DIR_CONTRATOS, archivo), "utf8"));
  const rutas = [];
  for (const [plantilla, item] of Object.entries(contrato.paths)) {
    for (const metodo of METODOS.filter((m) => item[m])) {
      const seguridad = item[metodo].security ?? contrato.security;
      if (!seguridad) throw new Error(`${nombre}: ${metodo.toUpperCase()} ${plantilla} no declara security`);
      rutas.push({
        metodo: metodo.toUpperCase(),
        plantilla,
        regex: new RegExp("^" + plantilla.replace(/\{[^}]+\}/g, "[^/]+") + "$"),
        alcances: seguridad.length === 0 ? null : Object.values(seguridad[0])[0],
      });
    }
  }
  servicios["/" + nombre] = { url, rutas };
}
if (faltantes.length > 0) {
  console.error("Faltan variables de entorno: " + faltantes.join(", "));
  process.exit(1);
}

// ---------- Utilidades ----------
const error = (res, status, codigo, mensaje) => res.status(status).json({ codigo, mensaje });
const iguales = (a, b) => {
  const x = Buffer.from(String(a)), y = Buffer.from(String(b));
  return x.length === y.length && crypto.timingSafeEqual(x, y);
};

const app = express();
app.get("/health", (req, res) => res.json({ estado: "ok" }));

// ---------- Emisor de tokens: POST /token (Client Credentials) ----------
app.post("/token", express.urlencoded({ extended: false }), express.json(), async (req, res) => {
  let { grant_type, client_id, client_secret, scope } = req.body || {};
  const basic = req.get("Authorization");
  if (basic && basic.startsWith("Basic ")) {
    const [id, ...resto] = Buffer.from(basic.slice(6), "base64").toString().split(":");
    client_id = client_id || id;
    client_secret = client_secret || resto.join(":");
  }
  const oauth = (status, e, d) => res.status(status).json({ error: e, error_description: d });

  if (grant_type !== "client_credentials") return oauth(400, "unsupported_grant_type", "Solo se admite client_credentials");
  const cliente = CLIENTES[client_id];
  if (!cliente || !client_secret || !iguales(cliente.secret, client_secret)) return oauth(401, "invalid_client", "Credenciales inválidas");

  const pedidos = scope ? String(scope).split(" ").filter(Boolean) : cliente.scopes;
  const noPermitidos = pedidos.filter((s) => !cliente.scopes.includes(s));
  if (noPermitidos.length > 0) return oauth(400, "invalid_scope", `Alcances no permitidos: ${noPermitidos.join(" ")}`);

  const token = await new SignJWT({ scope: pedidos.join(" ") })
    .setProtectedHeader({ alg: "HS256" })
    .setIssuer(ISSUER).setAudience(AUDIENCE).setSubject(client_id)
    .setIssuedAt().setExpirationTime(`${EXPIRA_SEG}s`)
    .sign(clave);
  res.set("Cache-Control", "no-store").json({ access_token: token, token_type: "Bearer", expires_in: EXPIRA_SEG, scope: pedidos.join(" ") });
});

// ---------- Todo lo demás: validar y reenviar ----------
app.use(express.raw({ type: "*/*", limit: "1mb" }));

app.use(async (req, res) => {
  const idPeticion = req.get("X-Request-Id") || crypto.randomUUID();
  res.set("X-Request-Id", idPeticion);

  // 1. ¿A qué servicio y operación corresponde?
  const prefijo = "/" + req.path.split("/")[1];
  const servicio = servicios[prefijo];
  const rutaServicio = servicio ? req.path.slice(prefijo.length) || "/" : null;
  const coinciden = servicio ? servicio.rutas.filter((r) => r.regex.test(rutaServicio)) : [];
  if (coinciden.length === 0) return error(res, 404, "ruta_no_encontrada", "Esa ruta no existe en ningún contrato del clúster");
  const ruta = coinciden.find((r) => r.metodo === req.method);
  if (!ruta) return res.set("Allow", coinciden.map((r) => r.metodo).join(", ")).status(405).json({ codigo: "metodo_no_permitido", mensaje: "Método no permitido en esa ruta" });

  // 2. Seguridad: token y alcances (las rutas públicas declaran security: [])
  if (ruta.alcances) {
    const encabezado = req.get("Authorization") || "";
    if (!encabezado.startsWith("Bearer ")) return error(res, 401, "no_autenticado", "Falta el token");
    let payload;
    try {
      ({ payload } = await jwtVerify(encabezado.slice(7), clave, { issuer: ISSUER, audience: AUDIENCE, algorithms: ["HS256"] }));
    } catch (e) {
      return error(res, 401, "token_invalido", e.code === "ERR_JWT_EXPIRED" ? "El token está vencido" : "El token no es válido");
    }
    const tiene = String(payload.scope || "").split(" ");
    const faltan = ruta.alcances.filter((a) => !tiene.includes(a));
    if (faltan.length > 0) return error(res, 403, "sin_permiso", `Falta el alcance: ${faltan.join(" ")}`);
  }

  // 3. Reenviar al servicio dueño, con la cabecera secreta
  const consulta = req.originalUrl.includes("?") ? "?" + req.originalUrl.split("?")[1] : "";
  const cabeceras = { "X-Gateway-Secret": GATEWAY_SECRET, "X-Request-Id": idPeticion };
  if (req.get("Content-Type")) cabeceras["Content-Type"] = req.get("Content-Type");
  const cuerpo = Buffer.isBuffer(req.body) && req.body.length > 0 ? req.body : undefined;

  try {
    const r = await fetch(servicio.url + rutaServicio + consulta, {
      method: req.method, headers: cabeceras, body: cuerpo, signal: AbortSignal.timeout(TIMEOUT_MS),
    });
    res.status(r.status);
    if (r.headers.get("content-type")) res.set("Content-Type", r.headers.get("content-type"));
    res.send(Buffer.from(await r.arrayBuffer()));
  } catch (e) {
    console.error(`[${idPeticion}] ${req.method} ${req.path} -> ${e.name}: ${e.message}`);
    error(res, 503, "servicio_no_disponible", `El servicio ${prefijo.slice(1)} no respondió a tiempo`);
  }
});

app.listen(PORT, () => console.log(`Gateway escuchando en el puerto ${PORT} con ${Object.keys(servicios).length} servicio(s)`));
