import hmac
import base64
import json
import logging
import os
import re
import sys
import time
import uuid
from pathlib import Path
from urllib.parse import parse_qs

import httpx
import jwt
import yaml
from fastapi import FastAPI, Request, Response
from fastapi.responses import JSONResponse

logging.basicConfig(level=logging.INFO)
log = logging.getLogger("gateway")

# ---------- Configuración (todo por variables de entorno) ----------
JWT_SECRET = os.getenv("JWT_SECRET", "")
GATEWAY_SECRET = os.getenv("GATEWAY_SECRET", "")
ISSUER = os.getenv("JWT_ISSUER", "emisor-cluster")
AUDIENCE = os.getenv("JWT_AUDIENCE", "cluster")
EXPIRA_SEG = int(os.getenv("TOKEN_EXPIRA_SEG", "300"))
TIMEOUT_S = int(os.getenv("TIMEOUT_MS", "3000")) / 1000
DIR_CONTRATOS = Path(os.getenv("DIR_CONTRATOS", Path.cwd() / "contratos"))
CLIENTES = json.loads(os.getenv("CLIENTES_JSON", "{}"))

if len(JWT_SECRET) < 32 or not GATEWAY_SECRET:
    sys.exit("Se requieren JWT_SECRET (mínimo 32 caracteres) y GATEWAY_SECRET")

# ---------- Tabla de rutas, construida desde los contratos OpenAPI ----------
METODOS = ["get", "post", "put", "patch", "delete"]
servicios = {}  # prefijo -> {"url": ..., "rutas": [...]}
faltantes = []

for archivo in sorted(DIR_CONTRATOS.glob("*.yaml")):
    nombre = archivo.stem
    variable = nombre.upper().replace("-", "_") + "_URL"
    url = os.getenv(variable)
    if not url:
        faltantes.append(variable)
        continue
    contrato = yaml.safe_load(archivo.read_text(encoding="utf-8"))
    rutas = []
    for plantilla, item in contrato["paths"].items():
        for metodo in [m for m in METODOS if m in item]:
            seguridad = item[metodo].get("security", contrato.get("security"))
            if seguridad is None:
                sys.exit(f"{nombre}: {metodo.upper()} {plantilla} no declara security")
            rutas.append({
                "metodo": metodo.upper(),
                "regex": re.compile("^" + re.sub(r"\{[^}]+\}", "[^/]+", plantilla) + "$"),
                "alcances": None if len(seguridad) == 0 else list(seguridad[0].values())[0],
            })
    servicios["/" + nombre] = {"url": url, "rutas": rutas}

if faltantes:
    sys.exit("Faltan variables de entorno: " + ", ".join(faltantes))

app = FastAPI(title="Gateway del clúster", docs_url=None, redoc_url=None, openapi_url=None)


def error(status: int, codigo: str, mensaje: str, headers: dict | None = None):
    return JSONResponse(status_code=status, content={"codigo": codigo, "mensaje": mensaje}, headers=headers)


@app.get("/health")
def health():
    return {"estado": "ok"}


# ---------- Emisor de tokens: POST /token (Client Credentials) ----------
@app.post("/token")
async def token(request: Request):
    crudo = (await request.body()).decode()
    if "application/json" in request.headers.get("content-type", ""):
        try:
            datos = json.loads(crudo or "{}")
        except ValueError:
            datos = {}
    else:
        datos = {k: v[0] for k, v in parse_qs(crudo).items()}

    client_id, client_secret = datos.get("client_id"), datos.get("client_secret")
    basic = request.headers.get("authorization", "")
    if basic.startswith("Basic "):
        id_, _, secreto = base64.b64decode(basic[6:]).decode().partition(":")
        client_id, client_secret = client_id or id_, client_secret or secreto

    def oauth(status, e, d):
        return JSONResponse(status_code=status, content={"error": e, "error_description": d})

    if datos.get("grant_type") != "client_credentials":
        return oauth(400, "unsupported_grant_type", "Solo se admite client_credentials")
    cliente = CLIENTES.get(client_id)
    if not cliente or not client_secret or not hmac.compare_digest(str(cliente["secret"]), str(client_secret)):
        return oauth(401, "invalid_client", "Credenciales inválidas")

    scope = datos.get("scope")
    pedidos = [s for s in scope.split(" ") if s] if scope else cliente["scopes"]
    no_permitidos = [s for s in pedidos if s not in cliente["scopes"]]
    if no_permitidos:
        return oauth(400, "invalid_scope", "Alcances no permitidos: " + " ".join(no_permitidos))

    ahora = int(time.time())
    carga = {"scope": " ".join(pedidos), "iss": ISSUER, "aud": AUDIENCE, "sub": client_id, "iat": ahora, "exp": ahora + EXPIRA_SEG}
    access_token = jwt.encode(carga, JWT_SECRET, algorithm="HS256")
    return JSONResponse(
        content={"access_token": access_token, "token_type": "Bearer", "expires_in": EXPIRA_SEG, "scope": carga["scope"]},
        headers={"Cache-Control": "no-store"},
    )


# ---------- Todo lo demás: validar y reenviar ----------
@app.api_route("/{ruta:path}", methods=["GET", "POST", "PUT", "PATCH", "DELETE"])
async def reenviar(ruta: str, request: Request):
    id_peticion = request.headers.get("x-request-id") or str(uuid.uuid4())
    respuesta_id = {"X-Request-Id": id_peticion}

    # 1. ¿A qué servicio y operación corresponde?
    prefijo = "/" + ruta.split("/")[0]
    servicio = servicios.get(prefijo)
    ruta_servicio = (request.url.path[len(prefijo):] or "/") if servicio else None
    coinciden = [r for r in servicio["rutas"] if r["regex"].match(ruta_servicio)] if servicio else []
    if not coinciden:
        return error(404, "ruta_no_encontrada", "Esa ruta no existe en ningún contrato del clúster", respuesta_id)
    op = next((r for r in coinciden if r["metodo"] == request.method), None)
    if op is None:
        return error(405, "metodo_no_permitido", "Método no permitido en esa ruta",
                     {**respuesta_id, "Allow": ", ".join(r["metodo"] for r in coinciden)})

    # 2. Seguridad: token y alcances (las rutas públicas declaran security: [])
    if op["alcances"]:
        encabezado = request.headers.get("authorization", "")
        if not encabezado.startswith("Bearer "):
            return error(401, "no_autenticado", "Falta el token", respuesta_id)
        try:
            carga = jwt.decode(encabezado[7:], JWT_SECRET, algorithms=["HS256"], issuer=ISSUER, audience=AUDIENCE)
        except jwt.ExpiredSignatureError:
            return error(401, "token_invalido", "El token está vencido", respuesta_id)
        except jwt.PyJWTError:
            return error(401, "token_invalido", "El token no es válido", respuesta_id)
        tiene = str(carga.get("scope", "")).split(" ")
        faltan = [a for a in op["alcances"] if a not in tiene]
        if faltan:
            return error(403, "sin_permiso", "Falta el alcance: " + " ".join(faltan), respuesta_id)

    # 3. Reenviar al servicio dueño, con la cabecera secreta
    cabeceras = {"X-Gateway-Secret": GATEWAY_SECRET, "X-Request-Id": id_peticion}
    if request.headers.get("content-type"):
        cabeceras["Content-Type"] = request.headers["content-type"]
    cuerpo = await request.body() or None
    try:
        async with httpx.AsyncClient(timeout=TIMEOUT_S) as cliente:
            r = await cliente.request(
                request.method, servicio["url"] + ruta_servicio, params=request.url.query or None,
                headers=cabeceras, content=cuerpo,
            )
    except httpx.HTTPError as e:
        log.error("[%s] %s %s -> %s: %s", id_peticion, request.method, request.url.path, type(e).__name__, e)
        return error(503, "servicio_no_disponible", f"El servicio {prefijo[1:]} no respondió a tiempo", respuesta_id)

    salida = {"X-Request-Id": id_peticion}
    return Response(content=r.content, status_code=r.status_code, media_type=r.headers.get("content-type"), headers=salida)
