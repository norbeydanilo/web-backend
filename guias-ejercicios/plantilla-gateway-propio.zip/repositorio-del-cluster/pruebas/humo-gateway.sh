#!/usr/bin/env bash
# Prueba de humo para el pipeline: no necesita los servicios de los grupos.
# Comprueba que el gateway arranca, entrega tokens y aplica la seguridad.
GATEWAY="${GATEWAY:-http://localhost:8080}"
fallos=0
verificar() { if [ "$2" = "$3" ]; then echo "OK     $1 ($3)"; else echo "FALLO  $1 (esperado $2, obtenido $3)"; fallos=$((fallos+1)); fi; }
estado() { curl -s -o /dev/null -w '%{http_code}' "$@"; }

TOKEN=$(curl -s -d "grant_type=client_credentials&client_id=${LECTOR_ID:-lector}&client_secret=${LECTOR_SECRET:-secreto-lector}" "$GATEWAY/token" \
  | sed -n 's/.*"access_token":"\([^"]*\)".*/\1/p')

verificar "El gateway está vivo" 200 "$(estado "$GATEWAY/health")"
verificar "Entrega un token" "si" "$([ -n "$TOKEN" ] && echo si || echo no)"
verificar "Rechaza credenciales malas" 401 "$(estado -d 'grant_type=client_credentials&client_id=x&client_secret=y' "$GATEWAY/token")"
verificar "Sin token: 401" 401 "$(estado "$GATEWAY/flota/vehiculos")"
verificar "Sin el alcance: 403" 403 "$(estado -X POST -H "Authorization: Bearer $TOKEN" -H 'Content-Type: application/json' -d '{}' "$GATEWAY/flota/vehiculos")"
verificar "Ruta que no está en ningún contrato: 404" 404 "$(estado -H "Authorization: Bearer $TOKEN" "$GATEWAY/flota/no-existe")"
verificar "Servicio sin responder: 503" 503 "$(estado -H "Authorization: Bearer $TOKEN" "$GATEWAY/flota/vehiculos")"

[ "$fallos" -eq 0 ] && echo "Prueba de humo superada." || { echo "$fallos prueba(s) fallaron."; exit 1; }
