# Gateway del clúster [nombre]

## Líder
- Nombre: 
- Por qué se eligió: 
- Reemplazo si no está disponible: 

## Responsabilidades
- 

## Decisiones tomadas
| Fecha | Decisión | Por qué |
| --- | --- | --- |
|  |  |  |

## Cómo se toman las decisiones


## Clientes registrados
| client_id | Servicio | Alcances |
| --- | --- | --- |
|  |  |  |
(Los secretos NO se escriben aquí.)
