const crypto = require("crypto");
const express = require("express");
const { SignJWT } = require("jose");

const PORT = process.env.PORT || 4000;
const JWT_SECRET = process.env.JWT_SECRET;
const ISSUER = process.env.JWT_ISSUER || "emisor-cluster";
const AUDIENCE = process.env.JWT_AUDIENCE || "cluster";
const KID = process.env.JWT_KID || "clave-1";
const EXPIRA_SEG = Number(process.env.TOKEN_EXPIRA_SEG || 300);

// Clientes permitidos: { "flota-mid": { "secret": "...", "scopes": ["vehiculos:leer"] }, ... }
const CLIENTES = JSON.parse(process.env.CLIENTES_JSON || "{}");

if (!JWT_SECRET || JWT_SECRET.length < 32) {
  console.error("JWT_SECRET es obligatorio y debe tener al menos 32 caracteres");
  process.exit(1);
}
const clave = new TextEncoder().encode(JWT_SECRET);

const app = express();
app.use(express.urlencoded({ extended: false }));
app.use(express.json());

const error = (res, status, codigo, descripcion) =>
  res.status(status).json({ error: codigo, error_description: descripcion });

const iguales = (a, b) => {
  const x = Buffer.from(String(a));
  const y = Buffer.from(String(b));
  return x.length === y.length && crypto.timingSafeEqual(x, y);
};

app.get("/health", (req, res) => res.json({ estado: "ok" }));

// Flujo Client Credentials (RFC 6749, sección 4.4).
app.post("/token", async (req, res) => {
  let { grant_type, client_id, client_secret, scope } = req.body || {};

  // También se admite HTTP Basic: Authorization: Basic base64(client_id:client_secret)
  const basic = req.get("Authorization");
  if (basic && basic.startsWith("Basic ")) {
    const [id, ...resto] = Buffer.from(basic.slice(6), "base64").toString().split(":");
    client_id = client_id || id;
    client_secret = client_secret || resto.join(":");
  }

  if (grant_type !== "client_credentials") {
    return error(res, 400, "unsupported_grant_type", "Solo se admite client_credentials");
  }
  const cliente = CLIENTES[client_id];
  if (!cliente || !client_secret || !iguales(cliente.secret, client_secret)) {
    return error(res, 401, "invalid_client", "Credenciales inválidas");
  }

  // Alcances pedidos (opcionales): deben ser un subconjunto de los permitidos al cliente.
  const pedidos = scope ? String(scope).split(" ").filter(Boolean) : cliente.scopes;
  const noPermitidos = pedidos.filter((s) => !cliente.scopes.includes(s));
  if (noPermitidos.length > 0) {
    return error(res, 400, "invalid_scope", `Alcances no permitidos: ${noPermitidos.join(" ")}`);
  }

  const token = await new SignJWT({ scope: pedidos.join(" ") })
    .setProtectedHeader({ alg: "HS256", kid: KID })
    .setIssuer(ISSUER)
    .setAudience(AUDIENCE)
    .setSubject(client_id)
    .setIssuedAt()
    .setExpirationTime(`${EXPIRA_SEG}s`)
    .sign(clave);

  res.set("Cache-Control", "no-store").json({
    access_token: token,
    token_type: "Bearer",
    expires_in: EXPIRA_SEG,
    scope: pedidos.join(" "),
  });
});

app.listen(PORT, () => console.log(`Emisor de tokens escuchando en el puerto ${PORT}`));
