// Genera la configuración de KrakenD a partir de los contratos OpenAPI.
//   contratos/flota.yaml  ->  prefijo /flota, destino en la variable FLOTA_URL
//   contratos/viajes-y-zonas.yaml -> prefijo /viajes-y-zonas, variable VIAJES_Y_ZONAS_URL
// Uso: node gateway/generar-config.js
const fs = require("fs");
const path = require("path");
const crypto = require("crypto");
const YAML = require("yaml");

const DIR_CONTRATOS = path.join(__dirname, "..", "contratos");
const DIR_SALIDA = path.join(__dirname, "salida");
const METODOS = ["get", "post", "put", "patch", "delete"];

function requerida(nombre) {
  const valor = process.env[nombre];
  if (!valor) faltantes.push(nombre);
  return valor;
}
const faltantes = [];

const JWT_SECRET = requerida("JWT_SECRET");
const GATEWAY_SECRET = requerida("GATEWAY_SECRET");
const EMISOR_URL = requerida("EMISOR_URL");
const ISSUER = process.env.JWT_ISSUER || "emisor-cluster";
const AUDIENCE = process.env.JWT_AUDIENCE || "cluster";
const KID = process.env.JWT_KID || "clave-1";

const archivos = fs.readdirSync(DIR_CONTRATOS).filter((f) => f.endsWith(".yaml"));
const servicios = archivos.map((archivo) => {
  const nombre = path.basename(archivo, ".yaml");
  const variable = nombre.toUpperCase().replace(/-/g, "_") + "_URL";
  return { nombre, variable, url: requerida(variable), contrato: YAML.parse(fs.readFileSync(path.join(DIR_CONTRATOS, archivo), "utf8")) };
});

if (faltantes.length > 0) {
  console.error("Faltan variables de entorno: " + faltantes.join(", "));
  process.exit(1);
}

const rutaKrakend = (ruta) => ruta; // OpenAPI y KrakenD usan la misma forma: /vehiculos/{id}

function alcancesDe(operacion, contrato) {
  const seguridad = operacion.security ?? contrato.security;
  if (!seguridad) throw new Error(`La operación ${operacion.operationId} no declara security`);
  if (seguridad.length === 0) return null; // pública
  return Object.values(seguridad[0])[0]; // lista de alcances del primer requisito
}

const endpoints = [];

// 1. Ruta pública para pedir tokens (la atiende el emisor de tokens).
endpoints.push({
  endpoint: "/token",
  method: "POST",
  output_encoding: "no-op",
  input_headers: ["Content-Type", "Authorization"],
  backend: [{ host: [EMISOR_URL], url_pattern: "/token", encoding: "no-op" }],
});

// 2. Una ruta por cada operación de cada contrato.
for (const s of servicios) {
  for (const [ruta, item] of Object.entries(s.contrato.paths)) {
    for (const metodo of METODOS.filter((m) => item[m])) {
      const operacion = item[metodo];
      const alcances = alcancesDe(operacion, s.contrato);
      const consultas = [...(item.parameters || []), ...(operacion.parameters || [])]
        .filter((p) => p.in === "query")
        .map((p) => p.name);

      const endpoint = {
        endpoint: `/${s.nombre}${rutaKrakend(ruta)}`,
        method: metodo.toUpperCase(),
        output_encoding: "no-op",
        input_headers: ["Content-Type"],
        input_query_strings: consultas,
        backend: [
          {
            host: [s.url],
            url_pattern: rutaKrakend(ruta),
            encoding: "no-op",
            extra_config: {
              "modifier/martian": {
                "header.Modifier": { scope: ["request"], name: "X-Gateway-Secret", value: GATEWAY_SECRET },
              },
            },
          },
        ],
      };

      if (alcances) {
        endpoint.extra_config = {
          "auth/validator": {
            alg: "HS256",
            jwk_local_path: "/etc/krakend/jwks.json",
            disable_jwk_security: true,
            audience: [AUDIENCE],
            issuer: ISSUER,
            scopes_key: "scope",
            scopes_matcher: "all",
            scopes: alcances,
          },
        };
      }
      endpoints.push(endpoint);
    }
  }
}

const config = {
  $schema: "https://www.krakend.io/schema/krakend.json",
  version: 3,
  name: "Gateway del clúster",
  port: 8080,
  timeout: "3s",
  endpoints,
};

// 3. El conjunto de claves (JWK) con la que el gateway verifica la firma de los tokens.
const jwks = { keys: [{ kty: "oct", kid: KID, alg: "HS256", use: "sig", k: Buffer.from(JWT_SECRET).toString("base64url") }] };

fs.mkdirSync(DIR_SALIDA, { recursive: true });
fs.writeFileSync(path.join(DIR_SALIDA, "krakend.json"), JSON.stringify(config, null, 2));
fs.writeFileSync(path.join(DIR_SALIDA, "jwks.json"), JSON.stringify(jwks, null, 2));
console.log(`Listo: ${endpoints.length} rutas (${servicios.map((s) => s.nombre).join(", ")}) en gateway/salida/`);
