// Comprueba un token contra gateway/salida/jwks.json, igual que lo haría el gateway.
// Uso: node gateway/verificar-token.js <token> [alcance-requerido]
const fs = require("fs");
const path = require("path");
const { decodeProtectedHeader, importJWK, jwtVerify } = require("jose");

const [token, requerido] = process.argv.slice(2);
if (!token) {
  console.error("Uso: node gateway/verificar-token.js <token> [alcance-requerido]");
  process.exit(1);
}
const jwks = JSON.parse(fs.readFileSync(path.join(__dirname, "salida", "jwks.json"), "utf8"));

// Se busca en el conjunto de claves la que coincide con el "kid" del encabezado del token.
const buscarClave = async () => {
  const { kid } = decodeProtectedHeader(token);
  const jwk = jwks.keys.find((k) => k.kid === kid);
  if (!jwk) throw Object.assign(new Error("kid desconocido"), { code: "KID_DESCONOCIDO" });
  return importJWK(jwk, "HS256");
};

buscarClave()
  .then((clave) =>
    jwtVerify(token, clave, {
      issuer: process.env.JWT_ISSUER || "emisor-cluster",
      audience: process.env.JWT_AUDIENCE || "cluster",
    })
  )
  .then(({ payload }) => {
    const alcances = String(payload.scope || "").split(" ");
    console.log("Firma, emisor, audiencia y vencimiento: VALIDOS");
    console.log("Cliente:", payload.sub, "| vence:", new Date(payload.exp * 1000).toISOString());
    console.log("Alcances:", alcances.join(", "));
    if (requerido) console.log(`Alcance ${requerido}:`, alcances.includes(requerido) ? "PRESENTE (200)" : "AUSENTE (403)");
  })
  .catch((e) => {
    console.log("Token RECHAZADO (401):", e.code || e.message);
    process.exit(2);
  });
