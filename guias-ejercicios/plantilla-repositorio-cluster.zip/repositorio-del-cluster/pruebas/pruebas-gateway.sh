#!/usr/bin/env bash
# Pruebas de humo del gateway: los casos 401, 403, 404 y 200.
# Uso: GATEWAY=http://localhost:8080 ./pruebas/pruebas-gateway.sh
GATEWAY="${GATEWAY:-http://localhost:8080}"
# Clientes de prueba (deben existir en CLIENTES_JSON del emisor de tokens)
ESCRITOR_ID="${ESCRITOR_ID:-viajes-mid}";  ESCRITOR_SECRET="${ESCRITOR_SECRET:-secreto-viajes}"
LECTOR_ID="${LECTOR_ID:-lector}";          LECTOR_SECRET="${LECTOR_SECRET:-secreto-lector}"

fallos=0
verificar() {  # verificar "descripción" esperado obtenido
  if [ "$2" = "$3" ]; then echo "OK     $1 (HTTP $3)"; else echo "FALLO  $1 (esperado $2, obtenido $3)"; fallos=$((fallos+1)); fi
}
estado() { curl -s -o /dev/null -w '%{http_code}' "$@"; }
pedir_token() {  # pedir_token client_id client_secret
  curl -s -d "grant_type=client_credentials&client_id=$1&client_secret=$2" "$GATEWAY/token" \
    | sed -n 's/.*"access_token":"\([^"]*\)".*/\1/p'
}

TOKEN_ESCRITOR=$(pedir_token "$ESCRITOR_ID" "$ESCRITOR_SECRET")
TOKEN_LECTOR=$(pedir_token "$LECTOR_ID" "$LECTOR_SECRET")
[ -z "$TOKEN_ESCRITOR" ] && echo "No se pudo obtener el token del escritor: revisen el emisor de tokens" && exit 1
[ -z "$TOKEN_LECTOR" ] && echo "No se pudo obtener el token del lector: revisen el emisor de tokens" && exit 1

JSON='Content-Type: application/json'
NUEVO='{"tipo":"scooter","bateriaPct":60}'

echo "--- Tokens"
verificar "Pedir token con credenciales malas" 401 "$(estado -d 'grant_type=client_credentials&client_id=x&client_secret=y' "$GATEWAY/token")"

echo "--- 401: el gateway rechaza"
verificar "Ruta protegida sin token" 401 "$(estado "$GATEWAY/flota/vehiculos")"
verificar "Ruta protegida con token inventado" 401 "$(estado -H 'Authorization: Bearer inventado' "$GATEWAY/flota/vehiculos")"

echo "--- 403: token válido, pero sin el alcance"
verificar "Crear con token de solo lectura" 403 "$(estado -X POST -H "Authorization: Bearer $TOKEN_LECTOR" -H "$JSON" -d "$NUEVO" "$GATEWAY/flota/vehiculos")"

echo "--- 200, 201 y 404"
verificar "Ruta pública (health)" 200 "$(estado "$GATEWAY/flota/health")"
verificar "Listar con token de lectura" 200 "$(estado -H "Authorization: Bearer $TOKEN_LECTOR" "$GATEWAY/flota/vehiculos")"
verificar "Crear con token de escritura" 201 "$(estado -X POST -H "Authorization: Bearer $TOKEN_ESCRITOR" -H "$JSON" -d "$NUEVO" "$GATEWAY/flota/vehiculos")"
verificar "Vehículo inexistente (404 del servicio dueño)" 404 "$(estado -H "Authorization: Bearer $TOKEN_LECTOR" "$GATEWAY/flota/vehiculos/zzz")"
verificar "Dato inválido (400 del servicio)" 400 "$(estado -X POST -H "Authorization: Bearer $TOKEN_ESCRITOR" -H "$JSON" -d '{"tipo":"scooter","bateriaPct":500}' "$GATEWAY/flota/vehiculos")"

if [ -n "$FLOTA_DIRECTO" ]; then
  echo "--- Llamada directa al servicio, saltándose el gateway"
  verificar "Servicio sin la cabecera del gateway" 403 "$(estado "$FLOTA_DIRECTO/vehiculos")"
fi

echo
echo "Falta una prueba manual: apaguen el servicio Flota y repitan un GET con token. Esperado: 503 (ver sección de errores)."
[ "$fallos" -eq 0 ] && echo "Todas las pruebas automáticas pasaron." || { echo "$fallos prueba(s) fallaron."; exit 1; }
